 --[[
    Skrypt wykoany Dla Gtao.pl Przez Barcioo
    GG: 62111935
    Skrypt testowany na serwerze: Your New Experience 

    Zakaz Zmiany Autora 

  ]]
--2761y
Gate1 = createObject(986,2497.1999511719,2769.3000488281,11.60000038147,0,0,90)
--2785y2
Gate2 = createObject(986,2497.1999511719,2777.3999023438,11.60000038147,0,0,270)

marker = createMarker(2496.66, 2773.26, 10.82-1,"cylinder",10,0,0,0,0) -- aby Marker był nie widoczny tylko dodać jedno 0 :)






function HitMarker(el,md) 
if getElementType(el) == "vehicle" then 
    gracz = getVehicleController(el)
   if getElementData(gracz , 'player:organization:id') == 1 then  -- tu zmienisz nazwe element daty  na którą ci pasuje po == się wypiszujesz true lub nr gangu 
     triggerClientEvent(gracz, "guiGate",gracz)
 else
    outputChatBox("Nie jesteś w pojedzie",gracz)
    outputChatBox("Lub Nie jestes w tej organizacji",gracz)
     end
   end
end

addEventHandler( "onMarkerHit", marker, HitMarker)







addEvent("OpenGate", true)
addEventHandler("OpenGate", root, function()
moveObject(Gate1,3000,2497.1999511719,2761,11.60000038147)
moveObject(Gate2,3000,2497.1999511719,2785,11.60000038147)
end)


function leaveHit(el,md)
 if getElementType(el) == "vehicle" then 
   gracz = getVehicleController(el)
     if getElementData(gracz , 'player:organization:id') == 1 then -- tu zmienisz nazwe element daty  na którą ci pasuje po == się wypiszujesz true lub nr gangu 
        moveObject(Gate1,3000,2497.1999511719,2769.3000488281,11.60000038147)
        moveObject(Gate2,3000,2497.1999511719,2777.3999023438,11.60000038147)
  end
 end
end

addEventHandler( "onMarkerLeave", marker, leaveHit)







