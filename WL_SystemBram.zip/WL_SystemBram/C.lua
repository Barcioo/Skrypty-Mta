
 --[[
    Skrypt wykoany Dla Gtao.pl Przez Barcioo
    GG: 62111935
    Skrypt testowany na serwerze: Your New Experience

    Zakaz Zmiany Autora 

  ]]

      button ={}

        button.open = guiCreateButton(0.78, 0.60, 0.15, 0.09, "Open", true)
        guiSetAlpha(button.open, 0.00)


        button.close = guiCreateButton(0.78, 0.72, 0.15, 0.09, "Close", true)
        guiSetAlpha(button.close, 0.00)    



local screenW, screenH = guiGetScreenSize()

addEventHandler("onClientRender", root,
    function()
        if zmienna then
        dxDrawImage(screenW * 0.7758, screenH * 0.4431, screenW * 0.1734, screenH * 0.4083, ":WL_SystemBram/img/pilot.png", 0, 0, 0, tocolor(255, 255, 255, 255), false)
     end
    end)

 addEvent("guiGate",true)
  addEvent("guiGateclose",true)

function guiGate()
   zmienna = true
  guiSetVisible(button.open, true)
  guiSetVisible(button.close, true)
  showCursor(true,true)
end
addEventHandler("guiGate", getRootElement(), guiGate)


function OpenGatec()
  if source ~= button.open then return end
    triggerServerEvent("OpenGate", root, localPlayer)
    zmienna = false
  guiSetVisible(button.open, false)
  guiSetVisible(button.close, false)
  showCursor(false,false)

end

addEventHandler ( "onClientGUIClick", root,OpenGatec)


function guiGateclose()
 if source ~= button.close then return end
  zmienna = false
  guiSetVisible(button.open, false)
  guiSetVisible(button.close, false)
  showCursor(false,false)
    
end
addEventHandler("guiGateclose", getRootElement(), guiGateclose)




addEventHandler("onClientResourceStart",resourceRoot,function()
  guiSetVisible(button.open, false)
  guiSetVisible(button.close, false)
  showCursor(false)
  zmienna = false
end)



