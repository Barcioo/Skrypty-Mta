 --[[
 Skrypt pisany dla serwisu GTAO.pl
 Autor: marcin778 ,barcioo , Juran 
 w jedeniej w funkcji pomógł Haze :)
 System jest pod ogrpg można edytować jak się podoba 
 Zakaz udostepnia na innych forach 
 Zakaz zmiany autora.
 --]]
 
 
 
 -- Tabela jest skończona w 65% 
 local niedozwolone = { -- w ostatnim rekordzie nie dawać przecinka po true lub false
     [524] = true,  --cement truck
     [532] = true, 
     [519] = true, --shamal
     [577] = true, -- At-400
     [592] = true, --adromeda
     [433] = true,
     [511] = true,
     [590] = true,
     [431] = true,
     [437] = true,
     [593] = true,
     [486] = true,
     [406] = true,
     [573] = true,
     [455] = true,
     [537] = true,
     [569] = true,
     [425] = true,
     [520] = true,
     [493] = true,
     [595] = true,
     [417] = true,
     [403] = true,
     [444] = true,
     [556] = true,
     [557] = true,
     [553] = true,
     [443] = true,
     [432] = true
     
     
}

local lawety = {
    {"policja", -2684.84961,-240.81404,7.44664,6,67,113},
    {"chuje muje", -2653.49487,-248.36574,7.04516,0,0,0}
}


local ID_LAWETY = 578
local colspheres = {}
local attX, attY, attZ = 0, -1.2, 0.5

for k, v in ipairs(lawety) do
    local laweta = createVehicle(ID_LAWETY, v[2], v[3], v[4])
    setElementData(laweta, "laweta", true)
    setElementData(laweta, "zaladunek", false)
    addVehicleUpgrade(laweta,1025)
    setVehicleColor(laweta, v[5], v[6],v[7])
    setVehiclePlateText( laweta, "Laweta" )
    setElementData(laweta,"vehicle:rank",1)
    setElementData(laweta,"vehicle:police", true)
    setElementFrozen(laweta,true)
    setElementData(laweta,"vehicle:fuel", 100)

    setElementData(laweta,"dbid", k)


end


addCommandHandler("zaladuj", function(player, command)
    if isPedInVehicle(player) then
        local veh = getPedOccupiedVehicle(player)
        if getElementModel(veh) == ID_LAWETY and not getElementData(veh, "zaladunek") and getElementData(veh, "laweta") then
            local x,y,z = getElementPosition(veh)
            colspheres[veh] = createColSphere(x,y,z, 7) -- domyslna wartosc np. 4 
            local elements = getElementsWithinColShape(colspheres[veh], "vehicle")
                for k, v in pairs(elements) do
                    if getElementModel(v) ~= ID_LAWETY and not niedozwolone[getElementModel(v)] then
                        attachElements(v, veh, attX, attY, attZ)
                        setElementData(veh, "zaladunek", v)
                        setElementFrozen(v, true)
                    end
                end
            if colspheres[veh] and isElement(colspheres[veh]) then
                destroyElement(colspheres[veh])
                colspheres[veh] = nil
            end
        else
            outputChatBox("Twój pojazd prawdopodobnie ma juz jakis załadunek", player)
        end
    else
        outputChatBox("Nie znajdujesz sie w pojeździe", player)
    end
end)

function getPositionFromElementOffset(element,offX,offY,offZ)

    local m = getElementMatrix ( element )  -- Get the matrix
    local x = offX * m[1][1] + offY * m[2][1] + offZ * m[3][1] + m[4][1]  -- Apply transform
    local y = offX * m[1][2] + offY * m[2][2] + offZ * m[3][2] + m[4][2]
    local z = offX * m[1][3] + offY * m[2][3] + offZ * m[3][3] + m[4][3]
    return x, y, z                               -- Return the transformed pointend
    
end
addCommandHandler("rozladuj", function(player, command)
    if isPedInVehicle(player) then
        local veh = getPedOccupiedVehicle(player)
        if getElementModel(veh) == ID_LAWETY and getElementData(veh, "zaladunek") then
            local zaladunek = getAttachedElements(veh)[1]
            if zaladunek and getElementType(zaladunek) == "vehicle" then
                local x,y,z = getElementPosition(zaladunek)
                detachElements(zaladunek, veh)
                setElementFrozen(findVehOnLavet(veh), false)
                local newX, newY, newZ = getPositionFromElementOffset(zaladunek, 3, 0, 0)
                setElementPosition(zaladunek, newX, newY, newZ)
                setElementData(veh, "zaladunek", false)
                outputChatBox("No chyba dziala", player)
            else
                outputChatBox("Brak załadunku bądź załadunek to nie pojazd", player)
            end
        else
            outputChatBox("Brak załadunku lub nie przyjechales lawetą", player)
        end
    end
end)



function findVehsOnLavet()
    for k,v in pairs(getElementsByType("vehicle")) do
        if getElementData(v, "zaladunek") == v then
            vehsOnLavet={}
            table.insert(vehsOnLavet, v)
            return vehsOnLavet
        end 
    end
    return false
end

function findVehOnLavet(veh)
    if isElement(veh) and getElementType(veh) == "vehicle"  then
        for k,v in pairs(getElementsByType("vehicle")) do
            if getElementData(veh, "zaladunek") == v then
                return v
            end
        end
    end
return false
end